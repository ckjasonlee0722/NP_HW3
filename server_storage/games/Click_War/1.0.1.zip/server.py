import socket
import threading
import argparse
import time
import json
import struct


def send_msg(sock, data):
    body = json.dumps(data).encode("utf-8")
    sock.sendall(struct.pack("!I", len(body)) + body)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int)
    parser.add_argument("--users", type=str)  # "1,2,3"
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--public-host", default="127.0.0.1")  # 接收但忽略
    parser.add_argument("--room-id", default=0)  # 接收但忽略
    parser.add_argument("--mode", default="")  # 接收但忽略
    parser.add_argument("--drop-ms", default="")  # 接收但忽略
    args = parser.parse_args()

    expected_users = args.users.split(",")
    scores = {uid: 0 for uid in expected_users}
    conns = []

    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind((args.host, args.port))
    s.listen(5)
    print(
        f"Click War Server listening on {args.port}, waiting for {len(expected_users)} players...")

    # 等待所有玩家連線
    while len(conns) < len(expected_users):
        c, a = s.accept()
        conns.append(c)
        print(f"Player connected: {a}")

    print("All players connected! Game Start!")

    # 廣播初始分數
    def broadcast():
        for c in conns:
            try:
                send_msg(c, {"scores": scores})
            except:
                pass

    broadcast()

    lock = threading.Lock()

    def handle(conn):
        while True:
            try:
                data = conn.recv(1024)
                if not data:
                    break
                # 簡單協議: 收到任何 data 就當作點擊
                uid = data.decode().strip()
                if uid in scores:
                    with lock:
                        scores[uid] += 1
                        if scores[uid] >= 50:  # 先到 50 分贏
                            scores["WINNER"] = uid
                    broadcast()
                    if "WINNER" in scores:
                        break
            except:
                break

    threads = []
    for c in conns:
        t = threading.Thread(target=handle, args=(c,))
        t.start()
        threads.append(t)

    for t in threads:
        t.join()
    time.sleep(2)
    s.close()


if __name__ == "__main__":
    main()
