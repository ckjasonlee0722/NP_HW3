import socket
import argparse
import json
import struct
import pygame
import sys
import threading


def recv_msg(sock):
    hdr = sock.recv(4)
    if not hdr:
        return None
    (ln,) = struct.unpack("!I", hdr)
    body = sock.recv(ln)
    return json.loads(body.decode("utf-8"))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--host")
    parser.add_argument("--port", type=int)
    parser.add_argument("--user-id")
    parser.add_argument("--role")  # 接收但忽略
    args = parser.parse_args()

    pygame.init()
    screen = pygame.display.set_mode((400, 300))
    pygame.display.set_caption(f"Click War - Player {args.user_id}")
    font = pygame.font.SysFont("Arial", 24)

    try:
        s = socket.create_connection((args.host, args.port))
    except:
        return

    scores = {}
    winner = None
    running = True

    def listen():
        nonlocal scores, winner, running
        while running:
            try:
                msg = recv_msg(s)
                if not msg:
                    break
                scores = msg.get("scores", {})
                if "WINNER" in scores:
                    winner = scores["WINNER"]
            except:
                break

    threading.Thread(target=listen, daemon=True).start()

    clock = pygame.time.Clock()
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE and not winner:
                    try:
                        s.sendall(str(args.user_id).encode())
                    except:
                        pass

        screen.fill((0, 0, 0))

        y = 20
        for uid, sc in scores.items():
            if uid == "WINNER":
                continue
            txt = f"Player {uid}: {sc}"
            color = (0, 255, 0) if uid == str(
                args.user_id) else (255, 255, 255)
            surf = font.render(txt, True, color)
            screen.blit(surf, (50, y))
            y += 40

        if winner:
            msg = "YOU WIN!" if winner == str(
                args.user_id) else f"Player {winner} WINS!"
            surf = font.render(msg, True, (255, 255, 0))
            screen.blit(surf, (100, 200))

        if not winner:
            help_txt = font.render(
                "PRESS SPACE TO CLICK!", True, (100, 100, 255))
            screen.blit(help_txt, (50, 250))

        pygame.display.flip()
        clock.tick(30)

    s.close()
    pygame.quit()


if __name__ == "__main__":
    main()
