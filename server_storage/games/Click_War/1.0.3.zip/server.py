import socket
import threading
import argparse
import time
import json
import struct


def send_msg(sock, data):
    body = json.dumps(data).encode("utf-8")
    sock.sendall(struct.pack("!I", len(body)) + body)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int)
    parser.add_argument("--users", type=str)  # "1,2,3"
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--public-host", default="127.0.0.1")  # 接收但忽略
    parser.add_argument("--room-id", default=0)  # 接收但忽略
    parser.add_argument("--mode", default="")  # 接收但忽略
    parser.add_argument("--drop-ms", default="")  # 接收但忽略
    args = parser.parse_args()

    expected_users = args.users.split(",")
    scores = {uid: 0 for uid in expected_users}
    conns = []

    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    # click_war_project/server.py

    # ... 前面省略 ...
    s.bind((args.host, args.port))
    s.listen(5)
    s.settimeout(10.0)  # [新增] 設定 10 秒超時，沒人連就不要等了

    print(f"Click War Server listening on {args.port}...")

    start_wait = time.time()
    while len(conns) < len(expected_users):
        try:
            c, a = s.accept()
            conns.append(c)
            print(f"Player connected: {a}")
        except socket.timeout:
            print("Waiting for players timed out...")
            break  # 超時就跳出，讓已連線的人可以玩，或者直接結束

    if len(conns) < len(expected_users):
        print("Not enough players, shutting down.")
        s.close()
        return  # 直接結束，避免卡死

    print("All players connected! Game Start!")
    # ... 後面省略 ...

    # 廣播初始分數
    def broadcast():
        for c in conns:
            try:
                send_msg(c, {"scores": scores})
            except:
                pass

    broadcast()

    lock = threading.Lock()

    def handle(conn):
        while True:
            try:
                data = conn.recv(1024)
                if not data:
                    break
                # 簡單協議: 收到任何 data 就當作點擊
                uid = data.decode().strip()
                if uid in scores:
                    with lock:
                        scores[uid] += 1
                        if scores[uid] >= 50:  # 先到 50 分贏
                            scores["WINNER"] = uid
                    broadcast()
                    if "WINNER" in scores:
                        break
            except:
                break

    threads = []
    for c in conns:
        t = threading.Thread(target=handle, args=(c,))
        t.start()
        threads.append(t)

    for t in threads:
        t.join()
    time.sleep(2)
    s.close()


if __name__ == "__main__":
    main()
